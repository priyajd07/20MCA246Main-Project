from django.apps import AppConfig


class LikePhotoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'like_photo'
